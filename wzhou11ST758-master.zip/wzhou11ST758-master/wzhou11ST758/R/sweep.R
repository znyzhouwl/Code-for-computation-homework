#' Sweep
#'
#' @param A The input symmetric matrix
#' @param k Diagonal index entry set on which to sweep
#' @return sweep matrix
#' @export

sweep<-function(A,k=NULL){
  dvector=diag(A)
  if(any(dvector[k]==0))
    stop("there are elements in diagnol sets are zeros")
  if(!isSymmetric(A))
    stop("Input matrix should be a symmetric matrix")
  if(is.null(k)){
    n=dim(A)[1]
    for(i in 1:n)
      A=sweep_k(A,i)
  }
  else{
    for(i in k){
      A=sweep_k(A,i)
    }
  }
  return(A)
}
