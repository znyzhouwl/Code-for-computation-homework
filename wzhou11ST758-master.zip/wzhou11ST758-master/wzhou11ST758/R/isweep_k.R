#' Inverse Sweep k
#'
#' \code{isweep_k} applies the inverse sweep operator to a symmetric matrix
#' on the kth diagonal entry if it is possible.
#'
#' @param A The input symmetric matrix
#' @param k Diagonal index on which to sweep
#' @return The inverse sweep matrix
#' @export

isweep_k<-function(A,k){
  if(A[k,k]==0)
    stop("the kth diagnol is 0")
  if(!isSymmetric(A))
    stop("Input matrix should be a symmetric matrix")
  m=dim(A)[1]
  B=A
  B[,k]=-A[,k]/A[k,k]
  B[k,]=-A[k,]/A[k,k]
  B[k,k]=-1/A[k,k]
  for(i in 1:m){
    for(j in 1:m){
      if(i!=k&&j!=k)
        B[i,j]=A[i,j]-A[i,k]*A[k,j]/A[k,k]
    }
  }
  return(B)
}
