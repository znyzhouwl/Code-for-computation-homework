#' Check Matrix is k-banded
#'
#' \code{check_k_banded} returns a Boolean variable indicating whether or
#' not a matrix is k-banded.
#'
#' @param A The input matrix
#' @param k bandwidth parameter
#' @export
check_k_banded <- function(A, k) {
  n=dim(A)[1]
  if(!isSymmetric(A))
    stop("matrix A must be a symmetric matrix")
  if(k<0||!(k==floor(k)))
    stop("k should be a non-negative integer")
  if(k>=n)
    return(FALSE)
  if(k==(n-1)&&A[1,n]==0)
    return(FALSE)
  if(k==(n-1)&&A[1,n]!=0)
    return(TRUE)
  for(i in 1:(n-k-1)){
    for(j in (i+k+1):n){
      if(A[i,j]!=0)
        return(FALSE)
    }
  }
  d=c()
  for(i in 1:(n-k)){
    d=c(d,A[i,(i+k)])
  }
  if(length(d[d!=0])==0)
    return(FALSE)
  return(TRUE)
}

#' Banded Cholesky
#'
#' \code{chol_banded} computes the Cholesky decomposition of a banded
#' positive definite matrix.
#'
#' @param A The input matrix
#' @param k bandwidth parameter
#' @param check check parameter check=1 means do check check=0 means no check
#' @export

chol_banded=function(A,k,check=1){
  if(check==1){
  if(!isSymmetric(A))
    stop("matrix is not symmetric")

    if(!check_k_banded(A,k))
      stop("matrix is not k banded")
  }
  n=dim(A)[1]
  R=Matrix(0,nrow=n,ncol=n,sparse=TRUE)
  for(i in 1:n){
    R[i,i]=sqrt(A[i,i])
    if(i<=(n-1)){
      R[i,(i+1):min((i+k),n)]=A[i,(i+1):min((i+k),n)]/R[i,i]
      A[(i+1):n,(i+1):n]=A[(i+1):n,(i+1):n]-R[i,(i+1):n]%*%t(R[i,(i+1):n])
    }
  }
  return(R)
}

