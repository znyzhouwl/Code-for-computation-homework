#' Objective Function for HSVM
#'
#' @param y binary response
#' @param X design matrix
#' @param beta regression coefficient vector
#' @param lambda regularization parameter
#' @export
fx_hsvm=function(y,X,beta,delta,lambda=1e-4){
  t=y*(X%*%beta)
  t1=ifelse(t>(1-delta)&t<=1,(1-t)^2/(2*delta),0)
  t2=ifelse(t<=1-delta,1-t-delta/2,0)
  return(sum(t1+t2)+lambda/2*sum(beta*beta))
}
#' Gradient for HSVM
#'
#' @param y binary response
#' @param X design matrix
#' @param beta regression coefficient vector
#' @param lambda regularization parameter
#' @export
gradf_hsvm=function(y,X,beta,delta,lambda=1e-4){
  t=y*(X%*%beta)
  t1=ifelse(t>(1-delta)&t<=1,(t-1)/delta,0)
  t2=ifelse(t<=1-delta,-1,0)
  return(t(X)%*%((t1+t2)*y)+lambda*beta)
}
#' Gradient Descent (Fixed Step-Size)
#'
#' @param y binary response
#' @param X design matrix
#' @param b0 initial parameter estimate
#' @param t step-size
#' @param max_iter maximum number of iterations
#' @param tol convergence tolerance
#' @export
gradient_descent_fixed=function(y,X,b0,delta,t,lambda=1e-4,max_iter=1e2,tol=1e-3){
  rfv=c()
  riv=c()
  fv=c()
  i=0
  rc=1
  while(i<=max_iter&&rc>tol){
    v1=fx_hsvm(y,X,b0,delta,lambda)
    b1=b0-t*gradf_hsvm(y,X,b0,delta,lambda)
    v2=fx_hsvm(y,X,b1,delta,lambda)
    fv=c(fv,v2)
    rfv=c(rfv,abs(v1-v2)/abs(v1))
    riv=c(riv,sqrt(sum((b1-b0)^2))/sqrt(sum(b0^2)))
    rc=abs(v2-v1)
    b0=b1
  }
  norm2=sqrt(sum(gradf_hsvm(y,X,b0,delta,lambda)^2))
  return(list(iterative_value=b0,objective_function=fv,norm_gradient=norm2,function_change=rfv,iteration_change=riv))
}
#' Gradient Descent (Backtracking Step-Size)
#'
#' @param y binary response
#' @param X design matrix
#' @param x0 initial parameter estimate
#' @param max_iter maximum number of iterations
#' @param tol convergence tolerance
#' @export
gradient_descent_backtrack=function(y,X,b0,delta,lambda=1e-4,max_iter=1e2,tol=1e-3){
  rfv=c()
  riv=c()
  fv=c()
  i=0
  rc=1
  while(i<=max_iter&&rc>tol){
    t=1
    while(fx_hsvm(y,X,b0-t*gradf_hsvm(y,X,b0,delta,lambda),delta,lambda)>=(fx_hsvm(y,X,b0,delta,lambda)-t/2*sum(gradf_hsvm(y,X,b0,delta,lambda)^2))){
      t=t/2
    }
    v1=fx_hsvm(y,X,b0,delta,lambda)
    b1=b0-t*gradf_hsvm(y,X,b0,delta,lambda)
    v2=fx_hsvm(y,X,b1,delta,lambda)
    fv=c(fv,v2)
    rfv=c(rfv,abs(v1-v2)/abs(v1))
    riv=c(riv,sqrt(sum((b1-b0)^2))/sqrt(sum(b0^2)))
    rc=abs(v2-v1)
    b0=b1
  }
  norm2=sqrt(sum(gradf_hsvm(y,X,b0,delta,lambda)^2))
  return(list(iterative_value=b0,objective_function=fv,norm_gradient=norm2,function_change=rfv,iteration_change=riv))
}

#' Gradient Descent
#'
#' @param y binary response
#' @param X design matrix
#' @param b0 initial parameter estimate
#' @param t step-size
#' @param max_iter maximum number of iterations
#' @param tol convergence tolerance
#' @export
gradient_descent=function(y,X,b0,delta,t=NULL,max_iter=1e2,tol=1e-3){
  if(is.null(t)){
    return(gradient_descent_backtrack(y,X,b0,delta,lambda,max_iter,tol));
  }
  else{
    return(gradient_descent_fixed(y,X,b0,delta,lambda,max_iter,tol));
  }
}
