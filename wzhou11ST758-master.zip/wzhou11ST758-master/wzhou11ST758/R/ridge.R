#' Ridge Regression
#'
#' \code{ridge_regression} returns the ridge regression coefficient estimates
#' for a sequence of regularization parameter values.
#'
#' @param y response variables
#' @param X design matrix
#' @param lambda vector of tuning parameters
#' @export

ridge_regression<-function(y,X,lambda){
  if(any(lambda<0))
    stop("the tunning parameter should be nonnegative")
  if(dim(X)[1]!=length(y))
    stop("reponse and design matrix are not conformable")
  m=length(lambda)
  p=dim(X)[2]
  beta=matrix(rnorm(m*p),p,m)
  for(l in 1:m){
    beta[,l]=solve(t(X)%*%X+lambda[l]*diag(p))%*%(t(X)%*%y)
}
  return(beta)

}
