#' Softthreshold operator
#'
#' @param x input vector
#' @param lambda threshold
#' @export
#' @examples
#' softthreshold(seq(-10, 10, length.out=10), 1)

softthreshold<-function(x,lambda){
  for(i in 1:length(x)){
    if(x[i]>lambda){
      x[i]=x[i]-lambda
    }
    if(x[i]<(-lambda)){
      x[i]=x[i]+lambda
    }
    if(abs(x[i])<=lambda){
      x[i]=0
    }
  }
  return(x)
}

#' Proximal mapping of the scaled nuclear norm
#'
#' @param X input matrix
#' @param gamma scale parameter
#' @export
#' @examples
#' set.seed(12345)
#' n <- 10; p <- 20
#' X <- matrix(rnorm(n*p), n, p)
#' Y <- prox_nuc(X, 1)

prox_nuc<-function(X,gamma){
  a=svd(X)
  D=softthreshold(a$d,gamma)
  Z=a$u%*%diag(D)%*%t(a$v)
  return(Z)
}

#' Project matrix onto observed index set
#'
#' @param X input matrix
#' @param Omega index set
#' @export
#' @examples
#' set.seed(12345)
#' n <- 10; p <- 20
#' X <- matrix(rnorm(n*p), n, p)
#' numel <- n*p
#' Omega <- sample(1:numel, floor(0.5*numel), replace=FALSE)
#' PX <- project_omega(X, Omega)
set.seed(12345)
n <- 10; p <- 20
X <- matrix(rnorm(n*p), n, p)
Y <- prox_nuc(X, 1)

project_omega<-function(X,Omega){
  x=as.vector(X)
  x[setdiff(1:(nrow(X)*ncol(X)),Omega)]=0
  return(matrix(x,nrow(X),ncol(X)))
}

numel <- n*p
Omega <- sample(1:numel, floor(0.5*numel), replace=FALSE)
PX <- project_omega(X, Omega)

#' Proximal-Gradient Step
#'
#' @param X input matrix
#' @param U current guess
#' @param Omega index set
#' @param lambda regularization parameter
#' @param t step size
#' @examples
#' set.seed(12345)
#' n <- 10; p <- 20
#' X <- matrix(rnorm(n*p), n, p)
#' numel <- n*p
#' Omega <- sample(1:numel, floor(0.5*numel), replace=FALSE)
#' U <- matrix(rnorm(n*p), n, p)
#' U[Omega] <- X[Omega]
#' lambda <- 1
#' t <- 1
#' U1 <- prox_step(X, U, Omega, lambda, t)

prox_step<-function(X,U,Omega,lambda,t){
  Z=U-t*(project_omega(U,Omega)-project_omega(X,Omega))
  return(prox_nuc(Z,t*lambda))
}


U <- matrix(rnorm(n*p), n, p)
U[Omega] <- X[Omega]
lambda <- 1
t <- 1
U1 <- prox_step(X, U, Omega, lambda, t)
#' Matrix Completion Loss
#'
#' @param X input matrix
#' @param U current guess
#' @param Omega index set
#' @param lambda regularization parameter
#' @examples
#' set.seed(12345)
#' n <- 10; p <- 20
#' X <- matrix(rnorm(n*p), n, p)
#' numel <- n*p
#' Omega <- sample(1:numel, floor(0.5*numel), replace=FALSE)
#' U <- matrix(rnorm(n*p), n, p)
#' U[Omega] <- X[Omega]
#' lambda <- 1
#' matrix_completion_loss(X, U, Omega, lambda)

matrix_completion_loss<-function(X,U,Omega,lambda){
  return(0.5*norm(project_omega(X,Omega)-project_omega(U,Omega),"F")^2+lambda*sum(svd(U)$d))
}

matrix_completion_loss(X,U,Omega,lambda)

#' Proximal Gradient Descent
#'
#' @param X input matrix
#' @param U current guess
#' @param Omega index set
#' @param lambda regularization parameter
#' @param t step-size parameter
#' @param max_iter maximum number of iterations
#' @param tol convergence tolerance
#' @export
#' @examples
#' set.seed(12345)
#' n <- 10; p <- 20
#' X <- matrix(rnorm(n*p), n, p)
#' numel <- n*p
#' Omega <- sample(1:numel, floor(0.5*numel), replace=FALSE)
#' U <- matrix(rnorm(n*p), n, p)
#' U[Omega] <- X[Omega]
#' lambda <- 1
#' pg_sol <- prox_grad(X, U, Omega, lambda, t=1e-5)

prox_grad<-function(X,U,Omega,lambda,max_iter=1e2,tol=1e-3){
  L=1
  t=1/L
  rel_change_fun=100;iter=1
  while(iter<=max_iter&&rel_change_fun>tol){
    U_new=prox_step(X,U,Omega,lambda,t)
    rel_change_fun=abs(matrix_completion_loss(X,U_new,Omega,lambda)-matrix_completion_loss(X,U,Omega,lambda))/abs(matrix_completion_loss(X,U,Omega,lambda))
    rel_change_iter=norm(as.vector(U_new-U),"2")/norm(as.vector(U),"2")
    U=U_new
    iter=iter+1
  }
  return(list(U,matrix_completion_loss(X,U,Omega,lambda),rel_change_fun,rel_change_iter,iter))
}

pg_sol <- prox_grad(X, U, Omega, lambda,1e2,1e-8)
#' Soft-Impute Algorithm
#'
#' @param X input matrix
#' @param U current guess
#' @param Omega index set
#' @param lambda regularization parameter
#' @param max_iter maximum number of iterations
#' @param tol convergence tolerance
#' @export
#' @examples
#' set.seed(12345)
#' n <- 10; p <- 20
#' X <- matrix(rnorm(n*p), n, p)
#' numel <- n*p
#' Omega <- sample(1:numel, floor(0.5*numel), replace=FALSE)
#' U <- matrix(rnorm(n*p), n, p)
#' U[Omega] <- X[Omega]
#' lambda <- 1
#' si_sol <- soft_impute(X, U, Omega, lambda)

soft_impute<-function(X,U,Omega,lambda,max_iter=1e2,tol=1e-3){
  rel_change_fun=100;iter=1
  while(iter<=max_iter&&rel_change_fun>tol){
    z=as.vector(X)
    u=as.vector(U)
    for(i in 1:(nrow(X)*ncol(X))){
      if(length(intersect(i,Omega))==0){
        z[i]=u[i]
      }
    }
    Z=matrix(z,nrow(X),ncol(X))
    U_new=prox_nuc(Z,lambda)
    rel_change_fun=abs(matrix_completion_loss(X,U_new,Omega,lambda)-matrix_completion_loss(X,U,Omega,lambda))/abs(matrix_completion_loss(X,U,Omega,lambda))
    rel_change_iter=norm(as.vector(U_new-U),"2")/norm(as.vector(U),"2")
    U=U_new
    iter=iter+1
  }
  return(list(U,matrix_completion_loss(X,U,Omega,lambda),rel_change_fun,rel_change_iter,iter))
}

si_sol<-soft_impute(X,U,Omega,lambda,1e2,1e-8)

