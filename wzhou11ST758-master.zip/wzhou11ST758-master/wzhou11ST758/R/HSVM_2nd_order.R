
#' Compute quasi-Newton Step (Naive) for HSVM
#'
#' @param X Design matrix
#' @param y Binary response vector
#' @param b Regression vector
#' @param g Gradient vector
#' @param delta HSVM parameter
#' @param lambda Regularization parameter
#' @export
newton_step_naive=function(X,y,b,g,delta,lambda=1e-4){
  t=y*(X%*%b)
  t=ifelse(t>(1-delta)&t<=1,1/delta,0)
  w=diag(as.vector(t))
  p=dim(X)[2]
  X1=lambda*diag(p)+t(X)%*%w%*%X
  R=chol(X1)
  t1=forwardsolve(t(R),g)
  t2=backsolve(R,t1)
  return(t2)
}
#' Compute quasi-Newton Step (Sherman-Morrison-Woodbury) for HSVM
#'
#' @param X Design matrix
#' @param y Binary response vector
#' @param b Regression vector
#' @param g Gradient vector
#' @param delta HSVM parameter
#' @param lambda Regularization parameter
#' @export

newton_step_smw=function(X,y,b,g,delta,lambda=1e-4){
  t=y*(X%*%b)
  t=ifelse(t>(1-delta)&t<=1,1/delta,0)
  w=diag(as.vector(t))
  n=dim(X)[1]
  H=diag(n)+1/lambda*w%*%X%*%t(X)

  t2=solve(H)
  d=X%*%g
  d=w%*%d
  d=t2%*%d
  d=t(X)%*%d/(lambda^2)
  step_smw=g/lambda-d
  return(step_smw)
}
#' Backtracking for steepest descent
#'
#' @param fx handle to function that returns objective function values
#' @param x current parameter estimate
#' @param g Gradient vector
#' @param d descent direction vector
#' @param t current step-size
#' @param alpha the backtracking parameter
#' @param beta the decrementing multiplier
#' @export
backtrack_descent=function(fx,x,g,d,t=1,alpha=0.5,beta=0.9){
  while(fx(x-t*d)>=fx(x)-alpha*t*(t(g)%*%d))
    t=beta*t
  return(-t*d)
}
#' Damped Newton's Method for Fitting HSVM
#'
#' @param y Binary response
#' @param X Design matrix
#' @param b Initial regression coefficient vector
#' @param delta HSVM parameter
#' @param method method to calculate the step size
#' @param lambda regularization parameter
#' @param max_iter maximum number of iterations
#' @param tol convergence tolerance
#' @export
hsvm_newton=function(X,y,b,delta,method="naive",lambda=1e-4,max_iter=1e2,tol=1e-3){
  fx=function(x){
    return(fx_hsvm(y,X,x,delta,lambda))
  }
  g=function(x){
    return(gradf_hsvm(y,X,x,delta,lambda))
  }
  if(method=="naive"){
    step=newton_step_naive(X,y,b,g(b),delta)
  }
  else{
    step=newton_step_smw(X,y,b,g(b),delta)
  }
  new_step=backtrack_descent(fx,b,g(b),step)
  i=1
  length=t(g(b))%*%(-new_step)/2
  b=b+new_step
  while(i<max_iter&&length>tol){
    if(method=="naive")
      step=newton_step_naive(X,y,b,g(b),delta)
    else
      step=newton_step_smw(X,y,b,g(b),delta)
    new_step=backtrack_descent(fx,b,g(b),step)
    length=t(g(b))%*%(-new_step)/2
    b=b+new_step
    i=i+1
  }
  return(b)

}

