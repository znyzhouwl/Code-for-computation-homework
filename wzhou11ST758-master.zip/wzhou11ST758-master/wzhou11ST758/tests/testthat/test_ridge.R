X1=matrix(rnorm(15),3,5)
y1=rnorm(2)
y=rnorm(3)
lambda1=-1
lambda=1
beta=ridge_regression(y,X1,lambda)
test_that("error message for ridge function",{
  expect_error(ridge_regression(y,X1,lambda1),"the tunning parameter should be nonnegative")
  expect_error(ridge_regression(y1,X1,lambda),"reponse and design matrix are not conformable")

})
test_that("the correctness of ridge function",{
  expect_equal(max(abs((t(X1)%*%X1+diag(5))%*%beta-t(X1)%*%y))<1e-5,TRUE)
})
