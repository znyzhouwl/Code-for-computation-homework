

k <- 3; m <- 10
A1 <- matrix(rnorm(m**2), m, m)
A2 <- A1 + t(A1)
A2 <- round(10*A2)/10
for (i in 1:m) {
  for (j in 1:m) {
    if (abs(i - j) > k) A2[i,j] <- 0
  }
}
A <- matrix(rnorm(m**2), m, m)
A <- A + t(A)
A <- round(10*A)/10
for (i in 1:m) {
  for (j in 1:m) {
    if (abs(i - j) > k||i>j) A[i,j] <- 0
  }
}
for(i in 1:m)
  A[i,i]=abs(A[i,i])+1
B=t(A)%*%A

test_that("error message for check_k_banded function",{
  expect_error(check_k_banded(A1,3),"matrix A must be a symmetric matrix")
  expect_error(check_k_banded(A2,2.3),"k should be a non-negative integer")
  expect_error(check_k_banded(A2,-1),"k should be a non-negative integer")
  })

test_that("correctness of check_k_banded function",{
  expect_equal(check_k_banded(A2,3),TRUE)
  expect_equal(check_k_banded(A2,4),FALSE)
})

test_that("error message for chol_banded function",{
  expect_error(chol_banded(A1,3),"matrix is not symmetric")
  expect_error(chol_banded(A2,4),"matrix is not k banded")
})

test_that("correctness of chol_banded function",{
  expect_equal(max(abs(chol(B)-chol_banded(B,3)))<1e-6,TRUE)
})
