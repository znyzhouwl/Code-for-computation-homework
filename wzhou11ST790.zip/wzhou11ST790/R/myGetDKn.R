#' Compute kth order differencing matrix
#'
#' @param k order of the differencing matrix
#' @param n Number of time points
#' @return D differencing matrix
#' @export
#'

myGetDKn=function(k,n){
  D=diag(n-k);
  for(i in 1:k){
    a=-diag(n-k+i);
    D=D%*%diff(a,1);
  }
  return(D)
}
