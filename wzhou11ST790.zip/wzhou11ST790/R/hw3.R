#' MM algorithm for smooth LAD regression
#'
#' @param X design matrix
#' @param y response
#' @param beta Initial regression coefficient vector
#' @param epsilon smoothing parameter
#' @param max_iter maximum number of iterations
#' @param tol convergence tolerance
#' @return final value
#' @return objective value
#' @return function change
#' @return iterative change
#' @export
smLAD <- function(X,y,beta,epsilon=0.25,max_iter=1e2,tol=1e-3) {
  X=as.matrix(X)
  m=ncol(X)
  n=nrow(as.matrix(X))
  beta=rep(1,m);
  diff=100;
  i=0;
  riterative=c();
  rfunction=c();
  value=c();

  while(i<=max_iter&&diff>tol){
    i=i+1;
    a=rep(0,n);
    count=0;
    V=diag(n)
    for(j in 1:n){
      a[j]=1/sqrt((y[j]-t(X[j,])%*%beta)^2+epsilon);
      count=count+sqrt((y[j]-t(X[j,])%*%beta)^2+epsilon);
      V[j,j]=a[j];
    }

    beta1=(solve(t(X)%*%V%*%X))%*%t(X)%*%V%*%y;
    final_value=0;
    for(j in 1:n){
      final_value=final_value+sqrt((y[j]-t(X[j,])%*%beta1)^2+epsilon);
    }
    value=c(value,final_value);
    diff=abs(final_value-count);
    rfunction[i]=diff/count;
    riterative[i]=sqrt(t(beta1-beta)%*%(beta1-beta))/(sqrt(t(beta)%*%beta));
    beta=beta1;
  }
result=list(final_beta=beta,objective_value=value,function_change=rfunction,value_change=riterative);
return(result);
}

#' Compute Newton Step (Naive) for logistic ridge regression
#'
#' @param X Design matrix
#' @param y Binary response vector
#' @param beta Current regression vector estimate
#' @param g Gradient vector
#' @param lambda Regularization parameter
#' @return newtonstep
#' @export
newton_step_naive <- function(X, y, beta, g, lambda) {
  w=dlogis(X%*%beta);
  w_matrix=diag(length(w));
  for(i in 1:length(w)){
    w_matrix[i,i]=w[i];
  }
  A=lambda*diag(ncol(X))+t(X)%*%w_matrix%*%X;
  R=chol(A);
  sol1=forwardsolve(t(R),g(beta));
  newstep=backsolve(R,sol1);
  return(newstep);
}

#' Compute Newton Step (Sherman-Morrison-Woodbury) for logistic ridge regression
#'
#' @param X Design matrix
#' @param y Binary response vector
#' @param beta Current regression vector estimate
#' @param g Gradient vector
#' @param lambda Regularization parameter
#' @return newton step
#' @export
newton_step_smw <- function(X, y, beta, g, lambda) {
  i=1
  v=NULL
  while(i<=nrow(X)){
    t=sum(X[i,]*beta)
    v=c(v,plogis(t)*(1-plogis(t)))
    i=i+1
  }
  W_inverse=diag(1/v)
  cma=chol(W_inverse+1/lambda*X%*%t(X))
  inverse=chol2inv(cma)
  t=1/lambda*t(X)%*%inverse%*%(1/lambda*X%*%g(beta))
  b=1/lambda*g(beta)-t
  return(b)

}

#' Backtracking for steepest descent
#'
#' @param fx handle to function that returns objective function values
#' @param x current parameter estimate
#' @param t current step-size
#' @param df the value of the gradient of objective function evaluated at the current x
#' @param d descent direction vector
#' @param alpha the backtracking parameter
#' @param beta the decrementing multiplier
#' @return stepsize
#' @export
backtrack_descent <- function(fx, x, t, df, d, alpha=0.5, beta=0.9) {
  while(fx(x+t*d)>=fx(x)+alpha*t*t(df)%*%d){
    t=beta*t;
  }
  return(t);
}

#' Damped Newton's Method for Fitting Ridge Logistic Regression
#'
#' @param y Binary response
#' @param X Design matrix
#' @param beta Initial regression coefficient vector
#' @param lambda regularization parameter
#' @param naive Boolean variable; TRUE if using Cholesky on the Hessian
#' @param max_iter maximum number of iterations
#' @param tol convergence tolerance
#' @export
logistic_ridge_newton <- function(X, y, beta, lambda=0, naive=TRUE, max_iter=1e2, tol=1e-3) {
  fx=function(a){
    return(fx_logistic(y,X,a,lambda=10))
  }
  gradf=function(a){
    return(gradf_logistic(y,X,a,lambda=10));
  }



  if(naive==TRUE){
    x_nt=(-1)*newton_step_naive(X,y,beta,gradf,lambda);
  }
  else{
    x_nt=(-1)*newton_step_smw(X,y,beta,gradf,lambda);
  }

  nd=-1/2*t(gradf(beta))%*%x_nt
  i=0;
  while(i<=max_iter&&nd>tol){
    i=i+1;
    df=gradf(beta)

    t=backtrack_descent(fx,beta,1,df,x_nt);
    beta=beta+t*x_nt;





    if(naive==TRUE){
      x_nt=-newton_step_naive(X,y,beta,gradf,lambda);
    }
    else{
      x_nt=-newton_step_smw(X,y,beta,gradf,lambda);
    }
    nd=-1/2*t(gradf(beta))%*%x_nt

  }
  return(beta);
}
