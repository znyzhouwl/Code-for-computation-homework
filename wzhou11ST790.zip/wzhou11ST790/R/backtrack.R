#' Backtracking
#'
#' @param fx handle to function that returns objective function values
#' @param x current parameter estimate
#' @param t current step-size
#' @param df the value of the gradient of objective function evaluated at the current x
#' @param alpha the backtracking parameter
#' @param beta the decrementing multiplier
#' @return the selected step-size
#' @export


backtrack=function(fx,t,x,df,alpha=0.5,beta=0.9){
  while(fx(x-t*df)>=(fx(x)-alpha*t*t(df)%*%df)){
    t=beta*t;
  }
  return(t);
}
