#' Compute KKT residual
#'
#' @param y response
#' @param b primal variable
#' @param theta primal variable
#' @param v dual variable
#' @param D differencing matrix
#' @param lambda regularization parameter
#' @return KKT residual
#' @export

kkt_residual=function(y,b,v,D,lambda){
  tau=1:length(v);
  k=D%*%b
  tau[k > 1e-1] = abs(v[k > 1e-1]-lambda)
  tau[k < -1e-1] = abs(v[k < -1e-1]+lambda)
  tau[abs(k) <= 1e-1] = max(abs(v[abs(k) <= 1e-1])-lambda, 0)
  return (max(tau))
}
