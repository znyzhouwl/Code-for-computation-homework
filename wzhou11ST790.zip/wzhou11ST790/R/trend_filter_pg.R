#' Solve trend-filtering by proximal gradient on dual problem
#'
#' @param y response
#' @param k order of differencing matrix
#' @param v Initial dual variable
#' @param lambda regularization parameter
#' @param max_iter maximum number of iterations
#' @param tol convergence tolerance
#' @return final value
#' @return The objective function values
#' @return The relative change in the function values
#' @return The relative change in the iterate values
#' @return The KKT residual after every iteration
#' @return The duality gap after every iteration
#' @export








trend_filter_pg <- function(y, k, v, lambda=0, alpha=0.1, max_iter=1e2, tol=1e-3) {
  n = length(y)
  s = length(v)
  D = myGetDKn(k, n)
  b = (y-t(D)%*%v)
  fun_val = sum((y-b)^2)/2 + lambda*sum(abs(D%*%b))
  kkt_res = kkt_residual(y, b, v, D, lambda)
  gap = duality_gap(y, b, v, D, lambda)

  fun_diff = NULL
  iter_diff = NULL
  iter = diff = 1
  while(iter < max_iter && abs(diff) > tol){
    v1=v
    v = v + alpha*D%*%b
    v[v>lambda] = lambda
    v[v< (-lambda)] = -lambda
    b = y - t(D)%*%v
    fun_val = c(fun_val, sum((y-b)^2)/2 + lambda*sum(abs(D%*%b)))
    diff = fun_val[iter+1] - fun_val[iter]
    fun_diff = c(fun_diff, abs(diff)/abs(fun_val[iter]))
    iter_diff = c(iter_diff, sqrt(sum((v-v1)^2))/sum(v1^2))
    kkt_res = c(kkt_res, kkt_residual(y, b, v, D, lambda))
    gap = c(gap, duality_gap(y, b, v, D, lambda))
    iter = iter + 1

  }
  b=y-t(D)%*%v
  return(list(bhat=b,vhat = v, fun_val = fun_val, fun_diff = fun_diff,
              iter_diff = iter_diff, kkt_res = kkt_res, gap = gap))
}
