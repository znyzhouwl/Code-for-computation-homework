#' Compute duality gap
#'
#' @param y response
#' @param b primal variable
#' @param v dual variable
#' @param D differencing matrix
#' @param lambda regularization parameter
#' @return duality gap
#' @export

duality_gap=function(y,b,v,D,lambda){
  a1=t(y-b)%*%(y-b)/2+lambda*sum(abs(D%*%b))
  a2=(t(y)%*%y-t(y-t(D)%*%v)%*%(y-t(D)%*%v))/2
  return(abs(a1-a2))

}
