#' Solve trend-filtering by coordinate descent on dual problem
#'
#' @param y response
#' @param k order of differencing matrix
#' @param v Initial dual variable
#' @param lambda regularization parameter
#' @param max_iter maximum number of iterations
#' @param tol convergence tolerance
#' @return final value
#' @return The objective function values
#' @return The relative change in the function values
#' @return The relative change in the iterate values
#' @return The KKT residual after every iteration
#' @return The duality gap after every iteration
#' @return the value
#' @export

trend_filter_cd=function(y,k,v,lambda=0,max_iter=1e2,tol=1e-3){
  n=length(y)
  D=myGetDKn(k,n)
  s=length(v)
  b = (y-t(D)%*%v);
  fun_value=(t(y)%*%y-t(y-t(D)%*%v)%*%(y-t(D)%*%v))/2;
  KKT=kkt_residual(y,b,v,D,lambda)
  gap=duality_gap(y,b,v,D,lambda)
  relativef=NULL
  relativei=NULL
  i=diff=1
  while(i<=max_iter&&abs(diff)>tol){
    v1=v
    for(j in 1:s){
      r=y-t(D[-j,])%*%v[-j]
      v[j]=sum(r*D[j,])/sum(D[j,]*D[j,])
      pos = ifelse(v[j] > lambda, 1, 0)
      neg = ifelse(v[j] < -lambda, -1, 0)
      equ = ifelse(abs(v[j]) <= lambda, 1, 0)
      v[j] = lambda*(pos + neg) + equ*v[j]
    }
    b=(y-t(D)%*%v)
    gap=c(gap,duality_gap(y,b,v,D,lambda))
    KKT=c(KKT,kkt_residual(y,b,v,D,lambda))
    fun_value=c(fun_value,(t(y)%*%y-t(y-t(D)%*%v)%*%(y-t(D)%*%v))/2)
    diff=fun_value[i+1]-fun_value[i]
    relativef=c(relativef,abs(diff)/abs(fun_value[i]))
    relativei=c(relativei,sqrt(sum((v-v1)^2)/sum(v1^2)))
    i=i+1
  }
  b=y-t(D)%*%v
  return(list(bhat=b,vhat = v,  fun_value = fun_value,relativef=relativef,relativei=relativei , KKT = KKT, gap = gap))
}
