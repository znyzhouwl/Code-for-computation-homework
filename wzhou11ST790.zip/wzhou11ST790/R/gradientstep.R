#'Gradient Step
#'
#' @param gradf handle to function that returns gradient of objective function
#' @param x current parameter estimate
#' @param t step-size
#' @return the iterative value
#' @export


gradient_step=function(gradf,t,x){
  return(x-t*gradf(x));
}
