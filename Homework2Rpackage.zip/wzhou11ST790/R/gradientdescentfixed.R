#' Gradient Descent (Fixed Step-Size)
#'
#' @param fx handle to function that returns objective function values
#' @param gradf handle to function that returns gradient of objective function
#' @param x0 initial parameter estimate
#' @param t step-size
#' @param max_iter maximum number of iterations
#' @param tol convergence tolerance
#' @return the final iterate value
#' @return the objective function value
#' @return the 2-norm of the gradient values
#' @return the relative changes in the function values
#' @return the relative changes in the iterate values
#' @export





gradient_descent_fixed=function(fx,gradf,t,x0,max_iter=1e2,tol=1e-3){
  i=0;
  x=x0;
  rf=c();
  ri=c();
  f_final=fx(x);
  gradient_value=sqrt(t(gradf(x))%*%gradf(x));
  while(i<max_iter&&abs(fx(gradient_step(gradf,t,x))-fx(x))>=tol){
    i=i+1;
    rf=c(rf,abs(fx(gradient_step(gradf,t,x))-fx(x))/abs(fx(x)));
    ri=c(ri,sqrt(t(gradient_step(gradf,t,x)-x)%*%(gradient_step(gradf,t,x)-x))/sqrt(t(x)%*%x));
    x=gradient_step(gradf,t,x);
    f_final=fx(x);
    gradient_value=sqrt(t(gradf(x))%*%gradf(x));

  }
  result=list(final_value=x,final_objective=f_final,gradientvalue=gradient_value,change1=rf,change2=ri);
  return(result);
}
