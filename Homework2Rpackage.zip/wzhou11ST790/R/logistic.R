#' Objective Function for Logistic Regression
#'
#' @param y binary response
#' @param X design matrix
#' @param beta regression coefficient vector
#' @param lambda regularization parameter
#' @return object function of logistic regression
#' @export




fx_logistic=function(y,X,beta,lambda=0){
  z=0;
  for(i in 1:nrow(X)){
    z=z+log(1+exp(t(X[i,])%*%beta));
  }
  return(z-t(y)%*%X%*%beta+lambda*t(beta)%*%beta/2);
}

#' Gradient for Logistic Regession
#'
#' @param y binary response
#' @param X design matrix
#' @param beta regression coefficient vector
#' @param lambda regularization parameter
#' @return gradient of objective function of logistic regression
#' @export

gradf_logistic=function(y,X,beta,lambda=0){
  z=rep(0,ncol(X));
  for(i in 1:nrow(X)){
    z=z+exp(t(X[i,])%*%beta)/(1+exp(t(X[i,])%*%beta))*X[i,];
  }
  return(-t(X)%*%y+lambda*beta+z);
}
