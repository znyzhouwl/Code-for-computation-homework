#' Gradient Descent
#'
#' @param fx handle to function that returns objective function values
#' @param gradf handle to function that returns gradient of objective function
#' @param x0 initial parameter estimate
#' @param t step-size
#' @param max_iter maximum number of iterations
#' @param tol convergence tolerance
#' @return the final iterate value
#' @return the objective function value
#' @return the 2-norm of the gradient values
#' @return the relative changes in the function values
#' @return the relative changes in the iterate values
#' @export



gradient_descent=function(fx,gradf,x0,t=NULL,max_iter=1e2,tol=1e-3){
  if(is.null(t)){
    return(gradient_descent_backtrack(fx,gradf,x0));
  }
  else{
    return(gradient_descent_fixed(fx,gradf,t,x0));
  }
}
